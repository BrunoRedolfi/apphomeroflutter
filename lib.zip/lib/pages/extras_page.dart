import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// Extras con el switch y contador de cervezas
class ExtrasPage extends StatefulWidget {
  @override
  State<ExtrasPage> createState() => _ExtrasPageState();
}

class _ExtrasPageState extends State<ExtrasPage> {
  bool _beerCounterActive = false;
  int _beerCount = 0;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.all(16),
      children: [
        Text(
          'Extras de Homero 🍩🍺',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 20),

        // Switch estilo "botón" adaptativo
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Activar contador de cervezas 🍺',
              style: TextStyle(fontSize: 16),
            ),
            Switch.adaptive(
              value: _beerCounterActive,
              onChanged: (value) {
                setState(() => _beerCounterActive = value);
              },
            ),
          ],
        ),

        SizedBox(height: 20),

        if (_beerCounterActive) ...[
          Text(
            'Cervezas consumidas hoy: $_beerCount',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.yellow[700],
              foregroundColor: Colors.black,
            ),
            icon: Icon(Icons.add),
            label: Text("Agregar una Duff"),
            onPressed: () {
              setState(() => _beerCount++);
            },
          ),
        ],
      ],
    );
  }
}
