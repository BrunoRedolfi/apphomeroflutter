import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// Menú de cervezas Duff
class BeerMenuPage extends StatelessWidget {
  final List<Map<String, String>> beers = [
    {'name': 'Duff Normal', 'image': 'assets/duff_normal.jpg'},
    {'name': 'Duff Light', 'image': 'assets/duff_light.jpg'},
    {'name': 'Duff Dry', 'image': 'assets/duff_dry.jpg'},
    {'name': 'Duff Christmas', 'image': 'assets/duff_christmas.jpg'},
  ];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth > 600;
        final crossAxisCount = isWide ? 2 : 1;
        return GridView.builder(
          padding: EdgeInsets.all(16),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 1.5,
          ),
          itemCount: beers.length,
          itemBuilder: (context, index) {
            final beer = beers[index];
            return Card(
              color: Colors.yellow[100],
              elevation: 4,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Image.asset(
                        beer['image']!,
                        fit: BoxFit.cover,
                        width: double.infinity,
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    beer['name']!,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  SizedBox(height: 8),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
