import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

// Clase MyApp
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    const String appTitle = 'La App de la Taberna de Moe';
    return MaterialApp(
      title: appTitle,
      home: Scaffold(
        appBar: AppBar(
          title: const Text(appTitle),
          backgroundColor: Colors.yellow[800],
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              const ImageSection(
                image: 'assets/taberna.jpg',
              ),
              const TitleSection(
                name: 'Taberna de Moe',
                location: 'Springfield',
              ),
              const ButtonSection(),
              const TextSection(
                description:
                '¡Hola muchachos programadores!\n\n'
                    'Soy Homero Simpson y necesito una app para pedir cerveza Duff y pretzels '
                    'desde el sofá sin que Marge se entere.\n\n'
                    'Que tenga todas las cervezas Duff, fotos grandes de la comida, pedidos favoritos, '
                    'notificación sonora "D\'OH!" y mapa para no perderme.\n\n'
                    'Extra: contador de cervezas, recordatorio de beber agua y descuentos para empleados.',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Widget ImageSection
class ImageSection extends StatelessWidget {
  const ImageSection({super.key, required this.image});
  final String image;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Image.asset(
        image,
        height: 240,
        fit: BoxFit.cover,
      ),
    );
  }
}

// Widget TitleSection
class TitleSection extends StatelessWidget {
  const TitleSection({super.key, required this.name, required this.location});
  final String name;
  final String location;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
                Text(
                  location,
                  style: TextStyle(color: Colors.grey.shade600),
                ),
              ],
            ),
          ),
          Icon(Icons.local_bar, color: Colors.red[700]),
          const Text('🍺'),
        ],
      ),
    );
  }
}

// Widget ButtonSection
class ButtonSection extends StatelessWidget {
  const ButtonSection({super.key});

  void _showSnack(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          ElevatedButton.icon(
            icon: const Icon(Icons.menu_book),
            label: const Text('Ver menú'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.yellow[800], foregroundColor: Colors.black),
            onPressed: () => _showSnack(context, 'Ir al menú de cervezas Duff'),
          ),
          ElevatedButton.icon(
            icon: const Icon(Icons.favorite),
            label: const Text('Favoritos'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.brown[700], foregroundColor: Colors.white),
            onPressed: () => _showSnack(context, 'Ir a mis pedidos favoritos'),
          ),
        ],
      ),
    );
  }
}

// Widget TextSection
class TextSection extends StatelessWidget {
  const TextSection({super.key, required this.description});
  final String description;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Text(
        description,
        softWrap: true,
        style: const TextStyle(fontSize: 16),
      ),
    );
  }
}
