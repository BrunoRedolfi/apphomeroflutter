import 'dart:io' show Platform;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'pages/settings_page.dart';
import 'pages/beer_menu_page.dart';
import 'pages/favorites_page.dart';
import 'pages/extras_page.dart';

void main() {
  runApp(TabernadeMoeApp());
}

// -----------------------------------------------------------------------------
// Clase para representar cada destino de navegación
// -----------------------------------------------------------------------------
class AppNavItem {
  final IconData icon;
  final String label;
  final Widget page;

  const AppNavItem({
    required this.icon,
    required this.label,
    required this.page,
  });
}

// -----------------------------------------------------------------------------
// Lista de páginas principales de la app
// -----------------------------------------------------------------------------
final List<AppNavItem> mainNavItems = [
  AppNavItem(icon: Icons.local_bar, label: 'Menú Duff', page: BeerMenuPage()),
  AppNavItem(icon: Icons.favorite, label: 'Favoritos', page: FavoritesPage()),
  AppNavItem(icon: Icons.star, label: 'Extras', page: ExtrasPage()),
  AppNavItem(
    icon: Icons.settings,
    label: 'Configuración',
    page: SettingsPage(),
  ),
];

// -----------------------------------------------------------------------------
// App principal
// -----------------------------------------------------------------------------
class TabernadeMoeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'La App de la Taberna de Moe',
      theme: ThemeData(
        primarySwatch: Colors.yellow,
        textTheme: Platform.isIOS
            ? TextTheme(
                bodyMedium: CupertinoThemeData().textTheme.textStyle.copyWith(
                  fontSize: 16,
                ),
              )
            : null,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: AdaptiveNavigationScaffold(),
    );
  }
}

// -----------------------------------------------------------------------------
// Scaffold adaptativo
// -----------------------------------------------------------------------------
class AdaptiveNavigationScaffold extends StatefulWidget {
  @override
  State<AdaptiveNavigationScaffold> createState() =>
      _AdaptiveNavigationScaffoldState();
}

class _AdaptiveNavigationScaffoldState
    extends State<AdaptiveNavigationScaffold> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.sizeOf(context);
    final bool isCompact = screenSize.width < 600;

    return Scaffold(
      appBar: AppBar(
        title: Text(mainNavItems[_selectedIndex].label),
        backgroundColor: Colors.yellow[800],
        foregroundColor: Colors.black,
      ),
      body: Row(
        children: [
          if (!isCompact)
            NavigationRail(
              selectedIndex: _selectedIndex,
              onDestinationSelected: (index) =>
                  setState(() => _selectedIndex = index),
              labelType: NavigationRailLabelType.all,
              destinations: mainNavItems
                  .map(
                    (item) => NavigationRailDestination(
                      icon: Icon(item.icon),
                      label: Text(item.label),
                    ),
                  )
                  .toList(),
            ),
          Expanded(child: mainNavItems[_selectedIndex].page),
        ],
      ),
      bottomNavigationBar: isCompact
          ? BottomNavigationBar(
              type: BottomNavigationBarType.fixed, // importante para 4+ ítems
              currentIndex: _selectedIndex,
              onTap: (index) => setState(() => _selectedIndex = index),
              items: mainNavItems
                  .map(
                    (item) => BottomNavigationBarItem(
                      icon: Icon(item.icon),
                      label: item.label,
                    ),
                  )
                  .toList(),
              selectedItemColor: Colors.black,
              backgroundColor: Colors.yellow[700],
            )
          : null,
    );
  }
}
